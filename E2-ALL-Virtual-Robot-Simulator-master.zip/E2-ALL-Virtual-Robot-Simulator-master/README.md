# E2-ALL-Virtual-Robot-Simulator

# Week 5

Decided theme: Sidescrolling obstacle course.

The robot should calculate the best path through a series of randomly generated pillars and avoid any collision, should the robot survive it will win the game.

There will be a score board that will increase points for every pillar passed and decrease for every collision.

We are going to be using Tkinter throughout the project.

For the theme the menu background colour will be black and will contain a green 'start' button and a red 'exit' button. The colour for the wall of the actual game will be green and the pillars that the robot has to avoid will be red. The score board will be yellow and will be displayed with black writing.
The obstacle course will be randomly generated so the robot will have to face a different one each time.


Some of features of the Simulator:
 A timer,
 Will generate music when it either gains or loses a point,
 Will have randomised difficulty levels,
 Will respond to collision with a foreign object,
 Will respond to the red colour of the pillars.

I have created a file called "Game Code" as we all know our individual requirements add you're bit of code into the file. If you run into any issues please create a new issue and we will try and correct the problem
