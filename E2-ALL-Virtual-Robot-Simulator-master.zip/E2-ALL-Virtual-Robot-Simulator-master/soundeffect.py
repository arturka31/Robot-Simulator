import winsound

if* # the robot go thought the bar 
winsound.PlaySound('Mario_Coin.wav', winsound.SND_FILENAME)
elif robot score>>> 100%10 winsound.PlaySound('mario_power_up.wav'winsound.SND_FILENAME) 
else  #the robot hit the bar
winsound.PlaySound('Mario_death.wav', winsound.SND_FILENAME)
